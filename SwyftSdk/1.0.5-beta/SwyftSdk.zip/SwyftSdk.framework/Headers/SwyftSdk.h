//
//  SwyftSdk.h
//  SwyftSdk
//
//  Created by Tom Manuel on 5/6/19.
//  Copyright © 2019 Swyft. All rights reserved.
//

#import <UIKit/UIKit.h>


//! Project version number for SwyftSdk.
FOUNDATION_EXPORT double SwyftSdkVersionNumber;

//! Project version string for SwyftSdk.
FOUNDATION_EXPORT const unsigned char SwyftSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwyftSdk/PublicHeader.h>


